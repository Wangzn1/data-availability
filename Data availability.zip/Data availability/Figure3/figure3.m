clear
clc
shift_E_l1 = load("shift_E_l1.mat");
shift_E_l1 = shift_E_l1.shift_E_l1;
shift_E_l2 = load("shift_E_l2.mat");
shift_E_l2 = shift_E_l2.shift_E_l2;
shift_E_l3 = load("shift_E_l3.mat");
shift_E_l3 = shift_E_l3.shift_E_l3;
l1 = 131.5e-3;
l2 = 151e-3;
l3 = 1.473;
m1 = 20.13e-3;
m2 = 14.9e-3;
k1 = 1.64;
k2 = -0.53;
d = 7.7208e-2;
f0 = 7.3664e-2;
d1 = l2 + m1/2 + m2/2;
% f1_prime = (9.98e-2)*ratio;
% f2_prime = (-19.42e-2)*ratio;
f1 = 9.98e-2;
f2 = -19.42e-2;
E0 = 150;
L = 1.6048;%距离像方主面距离而不是第二个PMQ右侧距离
HH = 10.777e-2;%对于150 MeV电子两个主平面之间的距离
gamma = E0/0.511;
emit = 10e-6/gamma;        %归一化发射度34 nm
sigmay = 5e-6;
beta = sigmay^2/emit;
% delta_d = linspace(-10e-3,10e-3,100);
delta_d = linspace(-10e-3,10e-3,1000);
delta_L = linspace(-10e-3,10e-3,1000);
delta_m = linspace(-10e-3,10e-3,1000);

para1 = f0/(d^2*k1-f0*d*k2);
para2 = d*f0/L^2/(d*k1-f0*k2);
para3 = d/(-f0*f0*k2+f0*d*k1);
xi = f1+f2-d1;
derivate1 = f1*d1/xi^2 + f1/xi; derivate2 = -d1*f2/xi^2 - f2/xi;
derivate3 = -f1*f2/xi/xi;

a1 = [-10,-8,-6,-2,0,2,6,8,10];
a_d = [141,142.552,144.7,148.3512,150.08,151.7806,155.51,157.1945,158.95];
a_m = [148.3,148.7,149.1,149.6,150.08,150.5,150.9839,151.5071,151.72];
a_L = [150.06,150.06,150.06,150.06,150.08,150.06,150.06,150.06,150.02];

for ii = 1:length(delta_d)
    E_new4(ii) = 150 + 150*para1*delta_d(ii);%%%%文章d
    E_new5(ii) = 150 + para1*derivate1*delta_m(ii)*150 + para2*derivate2*delta_m(ii)*150 + para3*derivate3*delta_m(ii)*150;
    E_new6(ii) = 150 + 150*para2*delta_L(ii);%%文章L
end

set(gcf, 'Position', [573, 544,750, 350]);
% % 获取当前图形窗口的句柄
fig = gcf;

% 获取图形窗口的大小和位置
figPosition = get(fig, 'Position');

% 输出图形窗口的大小
disp(['图形窗口的位置和大小: [x, y, width, height] = ', mat2str(figPosition)])


plot(delta_d*1e3,E_new4,'Linewidth',2,'Color',[0.7094,0.1154,0.1752])
hold on
plot(delta_m*1e3,E_new5,'Linewidth',2,'Color',[0.3033,0.58,0.1167])
hold on
plot(delta_L*1e3,E_new6,'Linewidth',2,'Color',[0.0698,0.4264,0.5039])
hold on
% plot(delta_d*1e3,shift_E_l1,'Linewidth',2,'Color',[241/255,196/255,205/255])
% hold on
% plot(delta_m*1e3,shift_E_l2,'Linewidth',2,'Color',[185/255,222/255,78/255])
% hold on
% plot(delta_L*1e3,shift_E_l3,'Linewidth',2,'Color',[186/255,204/255,217/255])
% hold on
plot(a1, a_d, '^', 'LineWidth', 1.5, 'MarkerSize', 5,'Color',[0.7094,0.1154,0.1752]);
hold on
plot(a1, a_m, '^', 'LineWidth', 1.5, 'MarkerSize', 5,'Color',[0.3033,0.58,0.1167]);
hold on
plot(a1, a_L, '^', 'LineWidth', 1.5, 'MarkerSize', 5,'Color',[0.0698,0.4264,0.5039]);
hold on
ax = gca;
ax.FontSize = 14;

grid on
legend({'$\delta_{E_0}$ induced by $\delta l_1$: formula',...
    '$\delta_{E_0}$ induced by $\delta l_2$: formula',...
    '$\delta_{E_0}$ induced by $\delta l_3$: formula',...
    '$\delta_{E_0}$ induced by $\delta l_1$: GPT simulation', ...
    '$\delta_{E_0}$ induced by $\delta l_2$: GPT simulation',... ...
    '$\delta_{E_0}$ induced by $\delta l_3$: GPT simulation'},'FontSize', 12,'Interpreter', 'latex','Box','off')
xlabel('Length Change [mm]','FontSize',16)
ylabel('Imaging Energy [MeV]','FontSize',16)
text('Units', 'normalized', 'Position', [-0.13, 0.99], 'String', '(b)', ...
    'FontSize', 20)
