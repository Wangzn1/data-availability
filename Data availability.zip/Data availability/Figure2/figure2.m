clear
clc
d = 7.7208e-2;
f = 7.3664e-2;
L = 1.6048;
M = L/f;%%%%%%%%%%这里只是L/f这个系数，不用加负号
AA = load("del_E4.mat");
del_E4 = AA.del_E4;
alpha = linspace(-5,5,1000);
beta = linspace(0,2e-3,1000);
[A,B] = meshgrid(alpha,beta);
k1 = 1.64;
k2 = -0.53;
energy_wanted = 150;
R11 = -20.95;
R21 = -13.68;
R22 = -0.048;
dR11_dE = k1*M/energy_wanted;
dR12_dE1 = k2*d/energy_wanted + (k1-k2)*M*d/energy_wanted;
dR12_dE2 =  (k1-k2)*M*d/energy_wanted;

del_E1 = -(R11.*B.*(dR11_dE.*B - dR12_dE1.* A))./((dR11_dE.*B - dR12_dE1.* A).^2 + dR12_dE1^2 );
del_E2 = -(R11.*B.*(dR11_dE.*B - dR12_dE2.* A))./((dR11_dE.*B - dR12_dE2.* A).^2 + dR12_dE2^2 );
del_E3 = -(R11.*B.*(- dR12_dE2.* A))./((- dR12_dE2.* A).^2 + dR12_dE2^2 );
del_d = R11.*B.*((-R21.*B + R22.*A)./(R22^2 + (R21.*B - R22.*A).^2));
% subplot(4,1,1)
% imagesc(alpha,beta.*1e3,del_E1)
% xlabel('\alpha','FontName', 'Arial','FontSize',12)
% ylabel('\beta [mm]','FontName', 'Arial','FontSize',12)
% set(gca, 'YDir', 'normal'); % 确保 y 轴方向正常（从下到上）
% colorbar; % 添加颜色条
% colormap jet; % 设置颜色映射为 jet（渐变色）
% hold on; % 保持当前图形
% beta_line = beta*1e3;
% % % alpha_line1 = -1 + beta / d; % 计算对应的 x 值
% alpha_line1 = -sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% alpha_line2 = sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% plot(alpha,(dR12_dE1/dR11_dE)*alpha*1e3,'r','LineWidth', 2);
% plot(alpha_line1, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
% plot(alpha_line2, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
% 
% 
% xticks(-4:1:4); 
% ax = gca; % gca 表示获取当前坐标轴对象
% % 设置字体大小
% ax.FontSize = 16; % 将字体大小设置为 16
% cb = colorbar;
% % 为颜色条添加标题
% cb.Title.String = '\delta_E [MeV]'; % 设置标题
% cb.Title.FontSize = 12; % 设置标题字体大小
% 
% 
% subplot(4,1,2)
% imagesc(alpha,beta.*1e3,del_E2)
% xlabel('\alpha','FontName', 'Arial','FontSize',12)
% ylabel('\beta [mm]','FontName', 'Arial','FontSize',12)
% set(gca, 'YDir', 'normal'); % 确保 y 轴方向正常（从下到上）
% colorbar; % 添加颜色条
% colormap jet; % 设置颜色映射为 jet（渐变色）
% hold on; % 保持当前图形
% beta_line = beta*1e3;
% % % alpha_line1 = -1 + beta / d; % 计算对应的 x 值
% alpha_line1 = -sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% alpha_line2 = sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% plot(alpha,(dR12_dE2/dR11_dE)*alpha*1e3,'r','LineWidth', 2);
% plot(alpha_line1, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
% plot(alpha_line2, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
% 
% 
% xticks(-4:1:4); 
% ax = gca; % gca 表示获取当前坐标轴对象
% % 设置字体大小
% ax.FontSize = 16; % 将字体大小设置为 16
% cb = colorbar;
% % 为颜色条添加标题
% cb.Title.String = '\delta_E [MeV]'; % 设置标题
% cb.Title.FontSize = 12; % 设置标题字体大小
set(gcf, 'Position', [100, 100, 800, 600]);
subplot(2,1,1)
imagesc(alpha,beta.*1e3,del_E4)
% xlabel('\alpha','FontName', 'Arial','FontSize',12)
ylabel('\beta_i [mm]','FontSize',12,'FontName','Arial')
set(gca, 'YDir', 'normal'); % 确保 y 轴方向正常（从下到上）

colormap jet; % 设置颜色映射为 jet（渐变色）
hold on; % 保持当前图形
beta_line = beta*1e3;
xline(1, 'w--','LineWidth',2);
xline(-1, 'w--','LineWidth',2);
xticks(-4:1:4); 
ax = gca; % gca 表示获取当前坐标轴对象
% 设置字体大小
set(gca,'XTickLabel','');
ax.FontSize = 16; % 将字体大小设置为 16
% cb = colorbar;
% % 为颜色条添加标题
% cb.Title.String = '\delta_E [MeV]'; % 设置标题
% cb.Title.FontSize = 12; % 设置标题字体大小
% cb.FontName = 'Arial';
text(0.01, 0.9, '(a)', 'Units', 'normalized', 'FontSize', 18,'FontName','Arial');
text(0.7, 0.8, 'based on Eq. 2', 'Units', 'normalized', 'FontSize', 15,'FontName','Arial');

subplot(2,1,2)
imagesc(alpha,beta.*1e3,del_E3)
xlabel('\alpha_i','FontSize',13,'FontName','Arial')
ylabel('\beta_i [mm]','FontSize',13,'FontName','Arial')
set(gca, 'YDir', 'normal'); % 确保 y 轴方向正常（从下到上）

colormap jet; % 设置颜色映射为 jet（渐变色）
hold on; % 保持当前图形
% % alpha_line1 = -1 + beta / d; % 计算对应的 x 值
% alpha_line1 = -sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% alpha_line2 = sqrt(1+(k1/(k1+k2)*(beta.^2/d^2)));
% plot(alpha,(dR12_dE2/dR11_dE)*alpha*1e3,'r','LineWidth', 2);
% plot(alpha_line1, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
% plot(alpha_line2, beta_line,'w--', 'LineWidth', 2); % 绘制直线，黑色，线宽为 2
xline(1, 'w--','LineWidth',2);
xline(-1, 'w--','LineWidth',2);
xticks(-4:1:4); 
ax = gca; % gca 表示获取当前坐标轴对象
% 设置字体大小
ax.FontSize = 16; % 将字体大小设置为 16
% cb = colorbar;
% % 为颜色条添加标题
% cb.Title.String = '\delta_E [MeV]'; % 设置标题
% cb.Title.FontSize = 12; % 设置标题字体大小
% cb.FontName = 'Arial';
text(0.01, 0.9, '(b)', 'Units', 'normalized', 'FontSize', 18,'FontName','Arial');
text(0.7, 0.8, 'predicted by Eq. 6', 'Units', 'normalized', 'FontSize', 15,'FontName','Arial');

h1 = subplot(2,1,1); % 获取第一个子图的句柄
h2 = subplot(2,1,2); % 获取第二个子图的句柄
pos1 = get(h1, 'Position'); % 获取第一个子图的位置
pos2 = get(h2, 'Position'); % 获取第二个子图的位置
new_gap = 0.08; % 设置新的竖直方向间距
pos2(2) = pos2(2) + new_gap; % 调整第一个子图的垂直位置
% 应用调整后的位置
set(h1, 'Position', pos1); % 设置第一个子图的新位置
set(h2, 'Position', pos2); % 第二个子图保持原位置

% 计算colorbar跨越的位置
colorbar_pos = [pos1(1) + pos1(3) + 0.02, pos2(2), 0.02, pos1(2) + pos1(4) - pos2(2)];

% 添加colorbar
c = colorbar('Position', colorbar_pos);
c.Title.String = '\delta_E [MeV]'; % 设置标题
c.Title.FontSize = 15; % 设置标题字体大小
c.FontName = 'Arial';
clim([-1,1])


% imagesc(alpha,beta.*1e3,del_d.*1e3)
% hold on
% plot(alpha,R22/R21.*alpha*1e3,'r','LineWidth',2);
% xlabel('\alpha','FontName', 'Arial','FontSize',12)
% ylabel('\beta [mm]','FontName', 'Arial','FontSize',12)
% set(gca, 'YDir', 'normal'); % 确保 y 轴方向正常（从下到上）
% colorbar; % 添加颜色条
% colormap jet; % 设置颜色映射为 jet（渐变色）
% plot(alpha,(alpha*R22/R21-R22/R21)*1e3,'w--','LineWidth', 2);
% plot(alpha,(alpha*R22/R21+R22/R21)*1e3,'w--','LineWidth', 2);
% xticks(-4:1:4); 
% ax = gca; % gca 表示获取当前坐标轴对象
% % 设置字体大小
% % clim([-1,1]); % 设置颜色条范围为 [-5, 5]
% 
% ax.FontSize = 16; % 将字体大小设置为 16
% cb = colorbar;
% % 为颜色条添加标题
% cb.Title.String = '\delta [mm]'; % 设置标题
% cb.Title.FontSize = 12; % 设置标题字体大小










